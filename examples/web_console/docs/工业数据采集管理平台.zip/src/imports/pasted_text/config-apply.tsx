请基于当前已经完成的 IDC Gateway 后台设计系统，一次性补齐剩余所有业务页面。

不要重做已有页面，不要重做全局布局，不要改变视觉风格。

当前已确定的风格：

* 深色左侧导航
* 顶部 Header 状态栏
* 白色内容卡片
* Ant Design 风格
* 高信息密度工业后台
* 表格、筛选、Drawer、Modal、Tabs、Card、Tag、Badge 为主
* ECharts 风格用于趋势图
* 所有页面基于 React + TypeScript + Ant Design 可实现

已完成或已有基础的页面：

* Login
* Dashboard
* Protocols
* Live

本轮请一次性输出剩余页面的主状态，不需要展开全部异常状态。
重点是：页面结构完整、业务模块齐全、组件命名清晰，后续再逐页修复细节。

## 全局要求

所有页面都使用当前统一布局：

* 左侧导航保持不变
* 顶部 Header 保持不变
* 当前用户：张工 / Admin 管理员
* Header 显示：

  * 系统在线
  * WS 正常
  * 未生效项 3
  * 当前用户与角色

所有页面都需要包含：

* 页面标题
* 页面副标题
* 顶部操作按钮
* 筛选区
* 主表格或主内容区
* 必要的 Drawer / Modal 示例
* Empty / Error 状态暂时不用展开，后续再修

请优先保证页面齐全，不要在某一个页面消耗太多细节。

---

# 1. Config & Apply 配置发布

页面目标：

管理 draft config 与 active config 的差异，执行 Validate、Apply、版本查看和回滚。

接口：

* A 组 `config/*`

页面模块：

## 顶部标题区

标题：

* 配置发布 Config & Apply

副标题：

* 对比草稿与生效配置，校验后发布到运行配置

操作按钮：

* 刷新
* Validate 校验
* Apply 发布
* 丢弃草稿
* 查看审计日志

Apply 使用高风险强调样式。

## Summary Cards

4 个状态卡：

1. 当前生效版本

   * Active Version: v37
   * Applied at: 2026-06-18 10:22:47
   * Applied by: 张工

2. 草稿差异

   * Draft Diff: 3 项
   * Added: 1
   * Modified: 2
   * Deleted: 0

3. 校验状态

   * Passed
   * checked items: 128
   * warnings: 1
   * errors: 0

4. 发布状态

   * Ready to apply
   * last apply: 2026-06-18 10:22:47

## Diff 主区域

左侧：Draft Diff List
右侧：Diff Viewer

Diff List 字段：

* 类型
* 对象名称
* 变更类型
* 影响范围
* 来源页面
* 修改人
* 修改时间

示例：

* Added transport：MQTT 产线 B 网关
* Modified datapoint：锅炉水温 timeout 从 3000 改为 5000
* Modified conversion rule：R-204 字段映射调整

Diff 类型颜色：

* Added：绿色
* Modified：橙色或蓝色
* Deleted：红色

Diff Viewer：

* Tab: Visual Diff / JSON Diff
* Visual Diff 使用 side-by-side
* 左侧 Active Config
* 右侧 Draft Config
* 字段级差异高亮

## Validate Panel

展示校验结果：

* 校验通过，可以发布
* checked items: 128
* warnings: 1
* errors: 0

显示校验步骤：

1. Schema 校验
2. 引用完整性校验
3. 协议连接依赖校验
4. 权限与安全校验

## Apply Confirm Modal

请设计一个确认发布 Modal。

标题：

确认发布草稿配置？

内容：

* 当前版本：v37
* 新版本：v38
* 差异：3 项
* 影响对象：1 transport, 1 datapoint, 1 conversion rule
* 校验状态：Passed
* 操作者：张工

要求用户输入：

APPLY

按钮：

* 取消
* 确认发布

确认发布按钮只有输入 APPLY 后可点击。

## Version History

表格字段：

* 版本号
* 发布时间
* 发布人
* 变更摘要
* 校验结果
* 运行状态
* 操作

操作：

* 查看 Diff
* 回滚到此版本

同时设计一个简单 Rollback Modal：

标题：

确认回滚到版本 v37？

说明：

回滚会创建一个新的 draft config，仍需 Validate 和 Apply 后才会生效。

按钮：

* 取消
* 创建回滚草稿

---

# 2. Datapoints 采集点

页面目标：

管理点位和编解码配置。

接口：

* C 组接口

页面模块：

## 标题区

标题：

* 采集点 Datapoints

副标题：

* 管理设备点位、地址、数据类型与编解码配置

操作按钮：

* 新增采集点
* 批量导入
* 批量导出
* 刷新

## Filter Bar

过滤器：

* 关键字搜索：点位名称、地址、标签
* Transport 下拉
* 数据类型：number / boolean / string
* 状态：正常 / 告警 / 错误 / 禁用
* 标签筛选
* 重置

## Table

字段：

* 点位名称
* 地址
* 所属 Transport
* 数据类型
* 单位
* 编码/解码方式
* 采集模式
* 状态
* 最近更新时间
* 操作

操作：

* 编辑
* 查看实时
* 查看历史
* 删除

## Drawer

新增 / 编辑采集点 Drawer。

分区：

1. 基本信息

   * 点位名称
   * 标签
   * 备注
   * 是否启用

2. 地址配置

   * 所属 Transport
   * 地址
   * 寄存器类型 / topic / node id，根据协议变化
   * 采集周期

3. 数据配置

   * 数据类型
   * 单位
   * 精度
   * 默认值

4. 编解码配置

   * byte order
   * scale
   * offset
   * expression
   * quality mapping

底部按钮：

* 取消
* 保存草稿

保存后提示：

已保存为草稿，需要到 Config & Apply 发布后生效。

---

# 3. Polling 轮询任务

页面目标：

配置轮询窗口和周期任务。

接口：

* `/polls`

页面模块：

## 标题区

标题：

* 轮询任务 Polling

副标题：

* 管理采集点轮询周期、窗口与运行状态

操作按钮：

* 新增轮询任务
* 暂停全部
* 刷新

## Summary Cards

* 运行中任务
* 暂停任务
* 异常任务
* 下次执行时间

## Filter Bar

* 关键字
* Transport
* 状态：运行中 / 暂停 / 异常
* 周期范围
* 重置

## Table

字段：

* 任务名称
* 关联 Transport
* 关联点位数
* 轮询周期
* 时间窗口
* 状态
* 上次执行
* 下次执行
* 最近错误
* 操作

操作：

* 编辑
* 暂停 / 恢复
* 立即执行
* 删除

## Drawer

新增 / 编辑轮询任务。

字段：

* 任务名称
* Transport
* 点位选择
* 轮询周期
* 时间窗口
* 超时时间
* 重试次数
* 是否启用

底部按钮：

* 取消
* 保存草稿

---

# 4. Conversion 协议转换

页面目标：

配置协议转换规则，查看实时转换活动。

接口：

* D 组接口
* WebSocket: `conversion/*`

页面模块：

## 标题区

标题：

* 协议转换 Conversion

副标题：

* 配置源点位到目标协议的映射、变换和实时活动

操作按钮：

* 新增转换规则
* 启用 / 停用
* 刷新

## Summary Cards

* 启用规则
* 今日转换次数
* 失败次数
* 实时活动速率

## 主布局

左侧或上方：规则列表
右侧或下方：规则详情 + 实时活动

## Rule Table

字段：

* 规则名称
* 源 Transport
* 源点位
* 目标 Transport
* 目标点位 / Topic
* 变换方式
* 状态
* 最近执行
* 成功率
* 操作

操作：

* 编辑
* 测试转换
* 启用 / 停用
* 删除

## Drawer

新增 / 编辑转换规则。

分区：

1. 基本信息

   * 规则名称
   * 备注
   * 是否启用

2. 源配置

   * 源 Transport
   * 源点位
   * 源字段

3. 目标配置

   * 目标 Transport
   * 目标点位 / Topic
   * 目标字段

4. 变换配置

   * 直接映射
   * scale / offset
   * expression
   * enum mapping
   * fallback value

5. 测试转换

   * 输入示例值
   * 输出预览
   * 测试结果

## 实时活动面板

Event Stream / Timeline：

* 时间
* 规则
* 输入值
* 输出值
* 状态
* 错误信息

状态：

* success
* failed
* skipped

---

# 5. History 历史数据

页面目标：

查询历史数据，表格和图表展示，支持导出。

接口：

* `GET /data/history`

页面模块：

## 标题区

标题：

* 历史数据 History

副标题：

* 查询点位历史数据，支持趋势对比与导出

操作按钮：

* 查询
* 导出 CSV
* 导出 Excel

## Query Panel

字段：

* 时间范围
* 点位选择
* Transport
* 聚合方式：raw / avg / min / max
* 采样间隔：1s / 10s / 1m / 5m
* 质量过滤：Good / Bad / Uncertain

## Trend Chart

ECharts 趋势图。

要求：

* 支持多点位对比
* 显示单位
* 支持缩放
* 支持 tooltip
* 支持图例开关

## Table

字段：

* 时间
* 点位名称
* 值
* 单位
* 质量
* Transport
* 地址

## 状态

主页面做有数据状态即可。

另外设计一个简单“未查询”空态：

请选择时间范围和点位后点击查询。

---

# 6. Users & Roles 用户与角色

页面目标：

Admin 管理用户、角色和权限。

接口：

* H 组 `/users`
* H 组 `/roles`

页面模块：

## 标题区

标题：

* 用户与角色 Users & Roles

副标题：

* 管理用户、角色和按钮级权限

操作按钮：

* 新增用户
* 新增角色
* 刷新

## Tabs

* Users
* Roles
* Permission Matrix

## Users Table

字段：

* 用户名
* 显示名
* 角色
* 状态
* 最近登录
* 创建时间
* 操作

操作：

* 编辑
* 重置密码
* 禁用 / 启用
* 删除

## User Drawer

字段：

* 用户名
* 显示名
* 邮箱
* 手机
* 角色选择
* 状态
* 初始密码 / 重置密码

底部：

* 取消
* 保存

## Roles Table

字段：

* 角色名称
* 描述
* 用户数
* 权限数
* 更新时间
* 操作

## Permission Matrix

行：

* Dashboard
* Protocols
* Datapoints
* Polling
* Conversion
* Live
* History
* Config & Apply
* Settings
* Logs
* Users & Roles

列：

* View
* Create
* Edit
* Delete
* Apply
* Rollback
* Control
* Export

用 Checkbox 矩阵展示。

高风险权限：

* Apply
* Rollback
* Delete User
* System Maintenance

需要用 warning 标识。

## Confirm Modal

删除用户确认 Modal。

标题：

确认删除用户？

内容：

删除后用户将无法登录，该操作会写入审计日志。

按钮：

* 取消
* 确认删除

---

# 7. Logs 事件日志

页面目标：

查看系统事件和审计日志。

接口：

* `GET /system/events`
* `/audit`

页面模块：

## 标题区

标题：

* 事件日志 Logs

副标题：

* 查看系统事件、连接事件、配置变更与审计日志

操作按钮：

* 刷新
* 导出
* 清理日志

## Tabs

* System Events
* Audit Logs

## Filter Bar

* 时间范围
* 级别：info / warning / error
* 模块：system / transport / polling / conversion / auth / config
* 用户
* 关键字
* 重置

## System Events Table

字段：

* 时间
* 级别
* 模块
* 事件类型
* 消息
* 来源
* 操作

## Audit Logs Table

字段：

* 时间
* 用户
* 动作
* 资源
* 结果
* IP
* 详情

## Detail Drawer

显示：

* 事件详情
* 原始 payload
* 关联对象
* 请求 ID
* Trace ID

---

# 8. Settings 系统设置

页面目标：

系统级设置和维护操作。

接口：

* `/system/settings`
* `/system/maintenance/*`

页面模块：

## 标题区

标题：

* 系统设置 Settings

副标题：

* 管理日志级别、数据保留、WebSocket 与维护操作

操作按钮：

* 保存设置
* 重置
* 刷新

## Settings Sections

### 基础设置

* 系统名称
* 时区
* 语言

### 日志设置

* 日志级别：debug / info / warning / error
* 日志保留期
* 审计日志保留期

### 数据保留

* 实时数据缓存时间
* 历史数据保留期
* 自动清理开关

### WebSocket 设置

* 心跳间隔
* 重连间隔
* 最大重试次数
* latest-wins 开关说明

### 维护操作

危险操作区：

* 清理历史数据
* 清理事件日志
* 重启运行时
* 重新加载配置

危险操作使用红色或 warning 区域，并需要确认 Modal。

## Maintenance Confirm Modal

标题：

确认执行维护操作？

内容：

该操作可能影响实时采集和 WebSocket 连接，请确认当前无关键任务。

按钮：

* 取消
* 确认执行

---

# 9. API Docs

页面目标：

内嵌 Swagger API 文档。

接口：

* `/api/docs`

页面模块：

## 标题区

标题：

* API 文档 API Docs

副标题：

* 查看后端 REST API 与调试接口

操作按钮：

* 在新窗口打开
* 刷新
* 复制地址

## 主内容

白色卡片内嵌 Swagger 占位区域。

显示：

* Swagger UI
* `/api/docs`
* API groups:

  * Auth
  * System
  * Transports
  * Datapoints
  * Polling
  * Conversion
  * Data
  * Config
  * Users & Roles

## 加载失败状态

简单错误卡片：

API 文档加载失败

说明：

无法加载 `/api/docs`，请检查后端服务或文档配置。

按钮：

* 重试
* 在新窗口打开

---

# 输出要求

请一次性输出以下页面主画面：

1. Config & Apply 主页面
2. Config & Apply Apply 确认 Modal
3. Config & Apply Version History / Rollback Modal
4. Datapoints 主页面
5. Datapoints 新增 / 编辑 Drawer
6. Polling 主页面
7. Polling 新增 / 编辑 Drawer
8. Conversion 主页面
9. Conversion 新增 / 编辑 Drawer
10. History 主页面
11. Users & Roles 主页面
12. Permission Matrix
13. Logs 主页面
14. Logs Detail Drawer
15. Settings 主页面
16. Settings Maintenance Confirm Modal
17. API Docs 主页面

如果一次输出容量不够，请按以下优先级生成：

1. Config & Apply
2. Datapoints
3. Conversion
4. History
5. Users & Roles
6. Polling
7. Logs
8. Settings
9. API Docs

请不要在单个页面上展开太多状态，先保证所有页面都有主画面。

## 组件命名要求

请尽量使用以下组件名，便于前端实现：

* ConfigApplyPage
* DraftDiffList
* DiffViewer
* ApplyConfirmModal
* VersionHistoryTable
* DatapointsPage
* DatapointDrawer
* PollingPage
* PollingTaskDrawer
* ConversionPage
* ConversionRuleDrawer
* HistoryPage
* HistoryQueryPanel
* HistoryTrendChart
* UsersRolesPage
* PermissionMatrix
* LogsPage
* LogDetailDrawer
* SettingsPage
* MaintenanceConfirmModal
* ApiDocsPage

请保持 Auto Layout，图层命名清楚，页面之间复用当前设计系统。
